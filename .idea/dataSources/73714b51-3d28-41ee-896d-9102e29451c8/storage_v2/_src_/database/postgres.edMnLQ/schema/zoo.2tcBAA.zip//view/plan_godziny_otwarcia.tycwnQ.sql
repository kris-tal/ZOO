create view plan_godziny_otwarcia
            (dzien_tyg, godz_od, godz_do, rodzaj, wybieg, strefa, id_popisu, id_trener, imie, nazwisko, gatunek,
             min_ilosc, min_poz, nazwa, id_wybieg, licznosc)
as
SELECT plan_24h.dzien_tyg,
       plan_24h.godz_od,
       plan_24h.godz_do,
       plan_24h.rodzaj,
       plan_24h.wybieg,
       plan_24h.strefa,
       plan_24h.id_popisu,
       plan_24h.id_trener,
       plan_24h.imie,
       plan_24h.nazwisko,
       plan_24h.gatunek,
       plan_24h.min_ilosc,
       plan_24h.min_poz,
       plan_24h.nazwa,
       plan_24h.id_wybieg,
       plan_24h.licznosc
FROM zoo.plan_24h
WHERE plan_24h.godz_od > ((SELECT godziny_otwarcia.otwarcie
                           FROM zoo.godziny_otwarcia))
  AND plan_24h.godz_do < ((SELECT godziny_otwarcia.zamkniecie
                           FROM zoo.godziny_otwarcia))
ORDER BY plan_24h.dzien_tyg, plan_24h.godz_od;

alter table plan_godziny_otwarcia
    owner to kris;

