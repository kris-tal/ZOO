create view plan_24h
            (dzien_tyg, godz_od, godz_do, rodzaj, wybieg, strefa, id_popisu, id_trener, imie, nazwisko, gatunek,
             min_ilosc, min_poz, nazwa, id_wybieg, licznosc)
as
SELECT pt.dzien_tyg,
       pt.godz_od,
       pt.godz_do,
       CASE
           WHEN pt.id_sprzat IS NOT NULL THEN 'sprzatanie'::text
           WHEN pt.id_karm IS NOT NULL THEN 'karmienie'::text
           ELSE 'popis'::text
           END   AS rodzaj,
       w.id      AS wybieg,
       s.nazwa   AS strefa,
       p.id      AS id_popisu,
       pr.id     AS id_trener,
       pr.imie,
       pr.nazwisko,
       gat.nazwa AS gatunek,
       p.min_ilosc,
       p.min_poz,
       g.nazwa,
       g.id_wybieg,
       g.licznosc
FROM zoo.plan_tygodnia pt
         LEFT JOIN zoo.wybiegi w ON pt.id_sprzat = w.id
         LEFT JOIN zoo.popisy p ON pt.id_popis = p.id
         LEFT JOIN zoo.gatunki g ON pt.id_karm = g.id
         LEFT JOIN zoo.strefy s ON w.strefa = s.id
         LEFT JOIN zoo.pracownicy pr ON p.trener = pr.id
         LEFT JOIN zoo.gatunki gat ON p.gatunek = gat.id
ORDER BY pt.dzien_tyg, pt.godz_od;

alter table plan_24h
    owner to kris;

