create function check_godz_popisow() returns trigger
    language plpgsql
as
$$
BEGIN
    IF EXISTS (
        SELECT true
        FROM plan_tygodnia
        WHERE id_popis IS NOT NULL
        AND (godz_od < NEW.otwarcie OR godz_do > NEW.zamkniecie)
    ) THEN
        RAISE EXCEPTION 'Nowa godzina rozpoczęcia koliduje z istniejącymi popisami';
    END IF;

    RETURN NEW;
END;
$$;

alter function check_godz_popisow() owner to kris;

