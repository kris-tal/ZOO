create function silnia(n numeric) returns numeric
    language plpgsql
as
$$
    BEGIN
        IF n = 0 THEN RETURN 1; END IF;
        RETURN n * silnia(n - 1);
    END;
    $$;

alter function silnia(numeric) owner to kris;

