create function bilans_kont()
    returns TABLE(konto numeric, suma_wplat numeric, suma_wyplat numeric)
    language plpgsql
as
$$
    BEGIN
        RETURN QUERY
        SELECT k.nr_konta, SUM(CASE WHEN k.nr_konta = t.na_konto THEN t.kwota ELSE 0 END), SUM(CASE WHEN k.nr_konta = t.z_konta THEN t.kwota ELSE 0 END)
        FROM konta k LEFT JOIN transakcje t ON k.nr_konta = t.z_konta OR k.nr_konta = t.na_konto
        GROUP BY k.nr_konta;
    END;
    $$;

alter function bilans_kont() owner to kris;

