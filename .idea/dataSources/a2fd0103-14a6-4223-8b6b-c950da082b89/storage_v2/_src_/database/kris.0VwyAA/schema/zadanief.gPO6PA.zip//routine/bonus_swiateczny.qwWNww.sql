create function bonus_swiateczny(p numeric DEFAULT 0.01) returns void
    language plpgsql
as
$$
    DECLARE
        el RECORD;
    BEGIN
        FOR el IN SELECT * FROM bilans_kont() WHERE suma_wyplat > 0
        LOOP
            INSERT INTO transakcje (id, na_konto, kwota) VALUES (nextval('seq'), el.konto, ROUND(p * el.suma_wyplat, 2));
        END LOOP;
    END;
    $$;

alter function bonus_swiateczny(numeric) owner to kris;

