create function update_licznosc_gatunku() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE gatunki
    SET licznosc = (
        SELECT COUNT(*)
        FROM zwierzeta
        WHERE zwierzeta.gatunek = NEW.gatunek
    )
    WHERE id = NEW.gatunek;

    RETURN NEW;
END;
$$;

alter function update_licznosc_gatunku() owner to kris;

