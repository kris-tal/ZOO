create function oblicz_koszt(n numeric) returns numeric
    language plpgsql
as
$$
    BEGIN
    RETURN ROUND(n * 0.02, 2);
    END;
$$;

alter function oblicz_koszt(numeric) owner to kris;

